#include <stdio.h>

const int a = 10;

int main()
{
  printf("%d", a / 5);
  return 0;
}